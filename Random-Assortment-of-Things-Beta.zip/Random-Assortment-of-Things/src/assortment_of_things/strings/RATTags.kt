package assortment_of_things.strings

object RATTags
{



}