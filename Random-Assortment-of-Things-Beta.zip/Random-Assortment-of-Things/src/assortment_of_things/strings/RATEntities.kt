package assortment_of_things.strings

object RATEntities
{
    /*var OUTPOST_WARNING_BEACON = "rat_outpost_warning_beacon"
    var BLACKMARKET_WARNING_BEACON = "rat_blackmarket_warning_beacon"*/
}