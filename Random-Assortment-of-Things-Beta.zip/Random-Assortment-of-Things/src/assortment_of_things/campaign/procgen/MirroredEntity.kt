package assortment_of_things.campaign.procgen.customThemes

import com.fs.starfarer.api.campaign.SectorEntityToken

data class MirrorEntity(var originalEntity: SectorEntityToken, var mirroredEntity: SectorEntityToken)

