package assortment_of_things.abyss.hullmods.basic

import activators.ActivatorManager
import assortment_of_things.abyss.activators.ParticleStreamActivator
import assortment_of_things.abyss.hullmods.BaseAlteration
import com.fs.starfarer.api.combat.BaseHullMod
import com.fs.starfarer.api.combat.MutableShipStatsAPI
import com.fs.starfarer.api.combat.ShipAPI
import com.fs.starfarer.api.ui.TooltipMakerAPI
import com.fs.starfarer.api.util.Misc

class DrivefieldOverwriteHullmod : BaseAlteration() {


    var modID = "rat_drivefield_overwrite"

    override fun applyEffectsAfterShipCreation(ship: ShipAPI?, id: String?) {
        super.applyEffectsAfterShipCreation(ship, id)

        if (ship == null) return
    }

    override fun applyEffectsBeforeShipCreation(hullSize: ShipAPI.HullSize?, stats: MutableShipStatsAPI?, id: String?) {
        super.applyEffectsBeforeShipCreation(hullSize, stats, id)

        stats!!.maxBurnLevel.modifyFlat(id, 1f)
        stats.maxSpeed.modifyFlat(id, 10f)


    }

    override fun shouldAddDescriptionToTooltip(hullSize: ShipAPI.HullSize?, ship: ShipAPI?, isForModSpec: Boolean): Boolean {
        return false
    }

    override fun addPostDescriptionSection(tooltip: TooltipMakerAPI?, hullSize: ShipAPI.HullSize?, ship: ShipAPI?, width: Float, isForModSpec: Boolean) {



        var hc = Misc.getHighlightColor()
        var nc = Misc.getNegativeHighlightColor()

        tooltip!!.addSpacer(5f)
        tooltip.addPara("Increases the ships maximum burn level by 1 and improves its max speed in combat by 10 units.", 0f, Misc.getTextColor(), Misc.getHighlightColor(),
            "maximum burn", "1", "max speed", "10")

    }

}