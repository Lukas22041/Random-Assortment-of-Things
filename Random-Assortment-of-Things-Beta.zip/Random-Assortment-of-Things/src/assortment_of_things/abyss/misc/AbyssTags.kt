package assortment_of_things.abyss.misc

object AbyssTags {




    //Interactions
    var LOOTABLE = "rat_lootable"

    //Entities
    var DOMAIN_RESEARCH = "rat_domain_research_station"
    var DOMAIN_RESEARCH_PRODUCTION = "rat_domain_research_station_production"
    var DOMAIN_RESEARCH_SURVEY = "rat_domain_research_station_survey"

    var TRANSMITTER = "rat_transmitter"
    var TRANSMITTER_UNLOOTED = "rat_transmitter_unlooted"

    var LOST_CRATE = "rat_transmitter_unlooted"

    var OUTPOST = "rat_abyss_outpost"

    var HOSTILE_ICON = "rat_hostile_icon"

    var ABYSS_WRECK = "rat_abyss_wreck"

}
